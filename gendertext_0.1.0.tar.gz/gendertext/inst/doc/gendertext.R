## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)
library(gendertext)

## -----------------------------------------------------------------------------
data(gender_dictionary)
head(gender_dictionary, 10)
nrow(gender_dictionary)

## -----------------------------------------------------------------------------
gender_score(
  text = "Ladies and gentlemen, the chairman said he will call the policeman."
)

## -----------------------------------------------------------------------------
gender_score(
  text = "The chairman and the spokesman left.",
  unit = "matches"
)

## -----------------------------------------------------------------------------
gender_suggestions(
  text = "Our chairman said he will email the mailman and the stewardess."
)

## -----------------------------------------------------------------------------
gender_replace(
  text = "The Chairman called the policeman and the FIREMAN."
)

## -----------------------------------------------------------------------------
my_dict <- data.frame(
  gendered = c("dude", "bro"),
  neutral = c("person", "friend")
)
gender_suggestions(text = "Hey dude, thanks bro!", dictionary = my_dict)

## -----------------------------------------------------------------------------
txt <- system.file("extdata", "test.txt", package = "gendertext")
gender_score(path = txt)
head(gender_suggestions(path = txt))

## ----eval = requireNamespace("readtext", quietly = TRUE)----------------------
pdf <- system.file("extdata", "test.pdf", package = "gendertext")
gender_score(path = pdf)

